# Reference image asset bundle

Extract this archive at the root of the cloned repository. It adds the eight supplied screenshots under `docs/reference-images/`, matching the paths used by `docs/reference-images/README.md` and `docs/IMPLEMENTATION_PLAN.md`.

Original upload to repository filename mapping:

- `1000189015.jpg` -> `01-gameplay-portrait.jpg`
- `1000189022.jpg` -> `02-gameplay-landscape.jpg`
- `1000189020.jpg` -> `03-controllers-screen.jpg`
- `1000189019.jpg` -> `04-core-options-dialog.jpg`
- `1000189017.jpg` -> `05-cheat-code-dialog.jpg`
- `1000189016.jpg` -> `06-game-menu.jpg`
- `1000189018.jpg` -> `07-save-state-slots.jpg`
- `1000189021.jpg` -> `08-library-home.jpg`

The JPEGs are preserved at their uploaded resolution; they are visual references, not app artwork or ROM assets.
